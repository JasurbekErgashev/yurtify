import Foundation

struct ImageAsset: Codable {
    let imageName: String
    let credit: String
}
